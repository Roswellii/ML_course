1. 维度怎么搞？

   ![image-20211009170141133](C:\Users\lenovo\AppData\Roaming\Typora\typora-user-images\image-20211009170141133.png)

2. 矩阵乘法 2x1 mutiply 1x2

   ​	一维向量无法转置

3. 无限趋近，怎么判别？

4. 牛顿迭代法不可逆怎么办？

   ​		![image-20211009202225196](C:\Users\lenovo\AppData\Roaming\Typora\typora-user-images\image-20211009202225196.png)

   这么来改？

   ![image-20211009202829331](C:\Users\lenovo\AppData\Roaming\Typora\typora-user-images\image-20211009202829331.png)

   P1 P0就在这里